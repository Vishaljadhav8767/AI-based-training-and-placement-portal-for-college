from django.shortcuts import render, redirect, get_object_or_404
from django.core.mail import send_mail
from django.conf import settings
from django.contrib.auth import authenticate, login, logout as django_logout, get_user_model
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import EditProfileForm
from .models import Profile, Student
from datetime import datetime, timedelta
import random
from django.contrib.auth.models import User
from django.http import HttpResponse
from accounts.models import User 



def home(request):
    return render(request, 'accounts/home.html')

registration_data={}
def register(request):
    User = get_user_model()
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        password = request.POST.get("password")
        confirm_password = request.POST.get("confirm_password")

        if password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return render(request, "accounts/register.html")

        otp = random.randint(100000, 999999)
        otp_timestamp = datetime.now()
        request.session['registration_data'] = {
            'name': name,
            'email': email,
            'password': password,
            'otp': otp,
            'otp_timestamp': otp_timestamp.strftime("%Y-%m-%d %H:%M:%S")
        }

        try:
            send_mail(
                "Your OTP for Registration",
                f"Your OTP is {otp}. This OTP is valid for 3 minutes.",
                settings.DEFAULT_FROM_EMAIL,
                [email],
                fail_silently=False,
            )
            return redirect("otp_verify")
        except Exception as e:
            messages.error(request, "Error sending OTP. Please try again.")
            print(e)

    return render(request, "accounts/register.html")


def verify_otp(request):
    User = get_user_model()
    if request.method == "POST":
        user_otp = request.POST.get("otp")
        session_data = request.session.get("registration_data")

        if session_data:
            otp = session_data.get("otp")
            otp_timestamp = datetime.strptime(session_data.get("otp_timestamp"), "%Y-%m-%d %H:%M:%S")
            current_time = datetime.now()


            if int(user_otp) == otp:
                user = User.objects.create_user(
                    username=session_data['email'],
                    email=session_data['email'],
                    password=session_data['password']
                )
                student = Student.objects.create(user=user, name=session_data['name'], email=session_data['email'])
                Profile.objects.create(user=user)

                messages.success(request, 'Registration successful. Please log in.')
                return redirect('login')

            messages.error(request, "Invalid OTP. Please try again.")

    return render(request, "accounts/otp_verify.html")

def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')  # Use .get() instead of directly indexing
        password = request.POST.get('password')

        user = authenticate(request, username=email, password=password)

        if user is not None:
            login(request, user)
            return redirect('student_dashboard')
        else:
            messages.error(request, 'Invalid email or password')
            return redirect('login')

    return render(request, 'accounts/login.html')


from staff.utils import is_student_eligible, extract_eligibility  # Ensure these exist
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Student, Profile
from staff.models import Company
from staff.utils import extract_eligibility  # Ensure this function is correctly imported
@login_required
def student_dashboard(request):
    print(f"User {request.user} is logged in.")  # Debugging line
    try:
        student = Student.objects.get(user=request.user)
        print(f"Student found: {student}")  # Debugging line
    except Student.DoesNotExist:
        messages.error(request, 'Student information does not exist.')
        return redirect('home')

    try:
        profile = Profile.objects.get(user=request.user)
        print(f"Profile found: {profile}")  # Debugging line
    except Profile.DoesNotExist:
        messages.error(request, 'Profile does not exist.')
        return redirect('home')

    def is_student_eligible(company, student):
        """Checks if a student meets the eligibility criteria for a given company."""
        criteria = extract_eligibility(company.eligibility)

        # -- Check 10th Marks --
        if criteria['tenth'] is not None and (profile.tenth_marks is None or profile.tenth_marks < criteria['tenth']):
            return False
        
        # -- Check 12th Marks --
        if criteria['twelfth'] is not None and (profile.twelfth_marks is None or profile.twelfth_marks < criteria['twelfth']):
            return False

        # -- Check CGPA --
        if criteria['cgpa'] is not None:
            required = criteria['cgpa']
            if "cgpa" in company.eligibility.lower() and required <= 10:
                required *= 10  # Convert CGPA scale if needed
            if profile.aggregate_marks is None or profile.aggregate_marks < required:
                return False

        # -- Check Branch --
        if criteria['branch'] is not None:
            if not profile.department or profile.department.upper() not in criteria['branch']:
                return False

        # -- Check Year --
        if criteria['year'] is not None and profile.year.upper() != criteria['year']:
            return False

        return True

    # Get all companies and filter by eligibility
    companies = [company for company in Company.objects.all() if is_student_eligible(company, student)]

    # Determine overall eligibility
    is_eligible = bool(companies)

    return render(request, 'accounts/student_dashboard.html', {
        'student': student,
        'profile': profile,
        'companies': companies,
        'is_eligible': is_eligible,
    })


@login_required
def edit_profile(request):
    # Retrieve the Profile instance linked to the logged-in user
    student = get_object_or_404(Student, email=request.user.email) 
    profile, created = Profile.objects.get_or_create(user=request.user)
    
    if request.method == 'POST':
        form = EditProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully.')
            return redirect('student_dashboard')
        else:
            print("Form errors:", form.errors)  # Debugging line to view form errors in console
    else:
        form = EditProfileForm(instance=profile)
    
    return render(request, 'accounts/edit_profile.html', {
        'form': form,
        'profile':profile,
        'student_name': student.name,
        'student_email': student.email
    })

def aptitude(request):
    return render(request,'accounts/aptitude.html')

def coding(request):
    return render(request , 'accounts/coding.html')
    
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)

def logout(request):
    logout(request)
    return redirect('login')

def ForgotPassword(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        print("Email:", email)
        
        if User.objects.filter(email=email).exists():
            user = User.objects.get(email=email)
            print("User exists")
            
            # Generate reset link
            reset_link = f"http://127.0.0.1:8000/accounts/reset-password/{user.username}/"

            
            # Send email
            send_mail(
                "Reset Your Password",
                f"Hi {user.username},\n\nTo reset your password, click the link below:\n{reset_link}\n\nThank you.",
                settings.EMAIL_HOST_USER,
                [email],
                fail_silently=False,
            )
            return render(request, 'accounts/password_reset_email.html')
        else:
            return HttpResponse("This email is not registered with us.")
    
    return render(request, 'accounts/forgot_password.html')


# New Password Page View
def NewPasswordPage(request, user):
    try:
        userid = User.objects.get(username=user)
        print("User ID:", userid)
    except User.DoesNotExist:
        return HttpResponse("Invalid user.")
    
    if request.method == 'POST':
        pass1 = request.POST.get('password1')
        pass2 = request.POST.get('password2')

        if pass1 == pass2:
            userid.set_password(pass1)
            userid.save()
            return HttpResponse("Password has been reset successfully. You can now log in with your new password.")
        else:
            return HttpResponse("Passwords do not match. Please try again.")
    
    return render(request, 'accounts/new_password.html')

def HRInterview(request):
    return render(request,'accounts/hrinterview.html')

def interview_page(request):
    return render(request, 'accounts/interview.html')

