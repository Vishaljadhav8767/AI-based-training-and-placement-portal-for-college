from django import forms
from .models import Student  
from django.contrib.auth.hashers import make_password
from django import forms
from .models import Profile  # Import the Profile model


class EditProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['profile_image', 'department', 'tenth_marks', 'twelfth_marks', 'aggregate_marks', 'year', 'skills', 'resume']
        widgets = {
            'profile_image': forms.ClearableFileInput(attrs={'accept': 'image/jpeg, image/png'}),
            'resume': forms.ClearableFileInput(attrs={'accept': 'application/pdf'}),
        }

    def __init__(self, *args, **kwargs):
        super(EditProfileForm, self).__init__(*args, **kwargs)
        if not self.instance.pk:  # Only apply defaults on new forms
            self.fields['department'].initial = 'CS'
            self.fields['year'].initial = 'FE'



class UserRegistrationForm(forms.ModelForm):
    # Define the password fields separately
    password = forms.CharField(widget=forms.PasswordInput)
    confirm_password = forms.CharField(widget=forms.PasswordInput)
    
    class Meta:
        model = Student
        fields = ['name', 'email']  # Only fields that exist in the Student model
    
    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")

        if password != confirm_password:
            self.add_error("confirm_password", "Passwords do not match")
        
        return cleaned_data

'''class StudentProfileForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['branch', 'class_year', 'tenth_marks', 'twelfth_marks', 'cgpa', 'skills', 'certificates']
'''

