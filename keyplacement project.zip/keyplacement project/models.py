from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    # Custom fields can be added here if needed
    pass


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    profile_image = models.ImageField(upload_to='profile_images/', null=True, blank=True)
    department = models.CharField(
        max_length=50,
        choices=[
            ('CS', 'Computer Science'),
            ('AIDS', 'Artificial Intelligence and Data Science'),
            ('EC', 'Electronics & Communication'),
            ('ME', 'Mechanical Engineering'),
        ],
        default='CS',  # Default department set to Computer Science
        blank=False
    )
    tenth_marks = models.FloatField(null=True, blank=True)
    twelfth_marks = models.FloatField(null=True, blank=True)
    aggregate_marks = models.FloatField(null=True, blank=True)
    YEAR_CHOICES = [
        ('BE', 'BE'),
        ('TE', 'TE'),
        ('SE', 'SE'),
        ('FE', 'FE'),
    ]
    year = models.CharField(
        max_length=2,
        choices=YEAR_CHOICES,
        default='FE',  # Default year set to FE
        null=True,
        blank=True
    )
    skills = models.TextField(null=True, blank=True)
    resume = models.FileField(upload_to='resumes/', null=True, blank=True)

    def __str__(self):
        return self.user.username

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if self.profile_image:
            from PIL import Image
            img = Image.open(self.profile_image.path)
            if img.height > 300 or img.width > 300:
                output_size = (90, 90)
                img.thumbnail(output_size)
                img.save(self.profile_image.path)

    class Meta:
        db_table = 'training_profile'



class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, unique=True)
    name = models.CharField(max_length=100)
    email = models.EmailField()

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'Student'


from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models

# Custom User Manager
class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        """
        Create and return a regular user with an email and password.
        """
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        """
        Create and return a superuser with an email and password.
        """
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(email, password, **extra_fields)


# Custom User model
class CustomUser(AbstractUser):
    # Optional: Remove 'username' field if you don't need it.
    username = None
    email = models.EmailField(unique=True)
    mobile_number = models.CharField(max_length=15, null=True, blank=True)

    # Define the reverse relationships with `related_name` to avoid conflicts
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='customuser_groups',  # Avoid conflict with default 'user_set'
        blank=True
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='customuser_permissions',  # Avoid conflict with default 'user_permissions'
        blank=True
    )

    objects = CustomUserManager()

    # We use the email field as the unique identifier
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['password']

    def __str__(self):
        return self.email
