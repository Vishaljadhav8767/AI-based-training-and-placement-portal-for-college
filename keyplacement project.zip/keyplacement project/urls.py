from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from . import views


urlpatterns = [
    path('', views.home, name='home'),  
    path('register/', views.register, name='register'),  
    path('login/', views.login_view, name='login'),  
    path('student_dashboard/', views.student_dashboard, name='student_dashboard'),
    path('edit_profile/', views.edit_profile, name='edit_profile'),
    path('aptitude/',views.aptitude,name='aptitude'),
    path('coding/', views.coding, name='coding'),
    path('logout/', views.logout, name='logout'),
    path('otp-verify/', views.verify_otp, name='otp_verify'), 
    path('forgot-password/', views.ForgotPassword, name='forgot_password'),  
    path('reset-password/<str:user>/', views.NewPasswordPage, name='reset_password'),
    path('HRInterview',views.HRInterview,name='HRInterview'),
    path('interview/', views.interview_page, name='interview'),
    
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

